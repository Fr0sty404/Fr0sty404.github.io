#include <iostream>
#include <gtkmm-3.0/gtkmm.h>

int main(int argc , char* argv[]) {
    auto app = Gtk::Application::create(argc, argv, "com.example");
    Gtk::Window window;
    window.set_title("test");
    window.set_default_size(200,200);

    return app->run(window);
}